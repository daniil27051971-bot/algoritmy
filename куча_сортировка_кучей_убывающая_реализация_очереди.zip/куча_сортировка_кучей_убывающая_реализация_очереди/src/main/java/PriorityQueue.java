public class PriorityQueue<T> {
    private final Heap<Entry<T>> heap = new Heap<>();
    private long counter = 0;

    // размер очереди
    public int size() {
        return heap.size();
    }

    // является ли очередь пустой
    public boolean isEmpty() {
        return heap.isEmpty();
    }

    // добавить элемент с приоритетом, O(log n)
    public void put(T elem, int priority) {
        heap.insert(new Entry<>(priority, counter++, elem));
    }

    // добавить элемент с приоритетом по умолчанию (0)
    public void put(T elem) {
        put(elem, 0);
    }

    // взять элемент с наибольшим приоритетом, O(log n); null, если очередь пуста
    public T get() {
        Entry<T> top = heap.extractMax();
        return top == null ? null : top.elem;
    }

    // элемент с наибольшим приоритетом
    public T peek() {
        Entry<T> top = heap.peek();
        return top == null ? null : top.elem;
    }

    private static class Entry<E> implements Comparable<Entry<E>> {
        final int priority;
        final long order;
        final E elem;

        Entry(int priority, long order, E elem) {
            this.priority = priority;
            this.order = order;
            this.elem = elem;
        }

        @Override
        public int compareTo(Entry<E> other) {
            int c = Integer.compare(priority, other.priority);
            if (c != 0) {
                return c;
            }
            // при равных приоритетах "больше" та запись, что добавлена раньше
            return Long.compare(other.order, order);
        }
    }
}
