import java.util.ArrayList;
import java.util.List;
public class Heap<T extends Comparable<T>> {
    private final List<T> heap = new ArrayList<>();

    // размер кучи
    public int size() {
        return heap.size();
    }

    // является ли куча пустой
    public boolean isEmpty() {
        return heap.isEmpty();
    }

    // максимальный элемент
    public T peek() {
        return heap.isEmpty() ? null : heap.get(0);
    }

    // добавить элемент: кладём в конец и поднимаем вверх, O(log n)
    public void insert(T val) {
        heap.add(val);
        siftUp(heap, heap.size() - 1);
    }

    // забрать максимальный элемент: на его место ставим последний
    // и опускаем вниз, O(log n)
    public T extractMax() {
        if (heap.isEmpty()) {
            return null;
        }
        T top = heap.get(0);
        T last = heap.remove(heap.size() - 1);
        if (!heap.isEmpty()) {
            heap.set(0, last);
            siftDown(heap, 0, heap.size());
        }
        return top;
    }

    @Override
    public String toString() {
        return heap.toString();
    }

    // вспомогательные операции

    // Поднять элемент вверх, пока он больше своего родителя
    public static <E extends Comparable<E>> void siftUp(List<E> list, int i) {
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (list.get(i).compareTo(list.get(parent)) > 0) {
                swap(list, i, parent);
                i = parent;
            } else {
                break;
            }
        }
    }

    // Опустить элемент вниз, пока один из потомков больше него.
    // size - сколько первых элементов списка входит в кучу
    public static <E extends Comparable<E>> void siftDown(List<E> list, int i, int size) {
        while (true) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            int largest = i;
            if (left < size && list.get(left).compareTo(list.get(largest)) > 0) {
                largest = left;
            }
            if (right < size && list.get(right).compareTo(list.get(largest)) > 0) {
                largest = right;
            }
            if (largest == i) {
                break;
            }
            swap(list, i, largest);
            i = largest;
        }
    }

    private static <E> void swap(List<E> list, int i, int j) {
        E tmp = list.get(i);
        list.set(i, list.get(j));
        list.set(j, tmp);
    }
}
