import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //Задание 1 куча
        Heap<Integer> h = new Heap<>();
        for (int el : new int[]{19, 14, 53, 3, 15, 26, 59, 23, 55, 54}) {
            h.insert(el);
        }
        System.out.println("Куча: " + h);
        System.out.println("Максимум: " + h.peek());
        System.out.print("Извлекаем по одному:");
        while (!h.isEmpty()) {
            System.out.print(" " + h.extractMax());
        }
        System.out.println("\n");

        // Задание 2 массив  куча
        Integer[] arr = {3, 5, 20, 6, 1, 8, 2, 4, 11};
        System.out.println("Исходный массив: " + Arrays.toString(arr));
        HeapTools.buildMaxHeap(arr);
        System.out.println("После buildMaxHeap: " + Arrays.toString(arr)
                + " | куча: " + HeapTools.isMaxHeap(Arrays.asList(arr)));

        // Задание 2 дерево из узлов куча
        TreeNode<Integer> tree = new TreeNode<>(1,
                new TreeNode<>(5, new TreeNode<>(2), new TreeNode<>(7)),
                new TreeNode<>(3, null, new TreeNode<>(9)));
        System.out.println("\nДерево по уровням до:    " + HeapTools.levelOrder(tree)
                + " | куча: " + HeapTools.isMaxHeapTree(tree));
        HeapTools.heapifyTree(tree);
        System.out.println("Дерево по уровням после: " + HeapTools.levelOrder(tree)
                + " | куча: " + HeapTools.isMaxHeapTree(tree));

        // Задание 2 сортировка кучей
        Integer[] toSort = {3, 5, 20, 6, 1, 8, 2, 4, 11};
        HeapTools.heapSort(toSort);
        System.out.println("\nСортировка кучей: " + Arrays.toString(toSort));

        // Задание 3 очередь с приоритетом
        PriorityQueue<String> que = new PriorityQueue<>();
        que.put("написать отчёт", 2);
        que.put("ответить на письмо", 1);
        que.put("починить сервер", 10);
        que.put("созвон с командой", 2);
        que.put("купить кофе", 1);

        System.out.println("\nРазмер очереди: " + que.size());
        System.out.println("Следующий: " + que.peek());
        System.out.println("Порядок выдачи:");
        while (!que.isEmpty()) {
            System.out.println("  " + que.get());
        }
    }
}
