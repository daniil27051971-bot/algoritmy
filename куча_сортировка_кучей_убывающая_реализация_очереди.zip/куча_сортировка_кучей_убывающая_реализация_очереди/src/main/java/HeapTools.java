import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
public class HeapTools {

    // Вариант А: дерево задано массивом
    // Любой список - это двоичное дерево. Идём от последнего родителя к корню и опускаем каждый элемент вниз.
    public static <T extends Comparable<T>> void buildMaxHeap(List<T> list) {
        int n = list.size();
        for (int i = n / 2 - 1; i >= 0; i--) {
            Heap.siftDown(list, i, n);
        }
    }

    // Arrays.asList - это "окно" на массив, поэтому массив меняется на месте.
    public static <T extends Comparable<T>> void buildMaxHeap(T[] arr) {
        buildMaxHeap(Arrays.asList(arr));
    }

    // Вариант Б: дерево из узлов
    // Подходит для любого двоичного дерева.
    public static <T extends Comparable<T>> TreeNode<T> heapifyTree(TreeNode<T> root) {
        if (root == null) {
            return null;
        }
        // Обход сверху вниз: узел всегда попадает в список раньше своих потомков
        List<TreeNode<T>> nodes = new ArrayList<>();
        Deque<TreeNode<T>> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode<T> node = stack.pop();
            nodes.add(node);
            if (node.left != null) {
                stack.push(node.left);
            }
            if (node.right != null) {
                stack.push(node.right);
            }
        }
        // Идём в обратном порядке: сначала потомки, потом родитель.
        // К моменту обработки узла оба его поддерева уже являются кучами, остаётся опустить значение самого узла.
        for (int i = nodes.size() - 1; i >= 0; i--) {
            siftDownNode(nodes.get(i));
        }
        return root;
    }

    // Опустить значение узла вниз по дереву
    private static <T extends Comparable<T>> void siftDownNode(TreeNode<T> node) {
        while (true) {
            TreeNode<T> largest = node;
            if (node.left != null && node.left.val.compareTo(largest.val) > 0) {
                largest = node.left;
            }
            if (node.right != null && node.right.val.compareTo(largest.val) > 0) {
                largest = node.right;
            }
            if (largest == node) {
                break;
            }
            T tmp = node.val;
            node.val = largest.val;
            largest.val = tmp;
            node = largest;
        }
    }

    // Сортировка кучей
    // 1) собираем убывающую кучу;
    // 2) максимум (корень) меняем с последним элементом и уменьшаем кучу на 1;
    // 3) опускаем новый корень вниз и повторяем.
    // Максимумы уходят в конец, поэтому результат - по возрастанию.
    // Сортировка на месте, O(n log n).
    public static <T extends Comparable<T>> void heapSort(List<T> list) {
        int n = list.size();
        buildMaxHeap(list);
        for (int end = n - 1; end > 0; end--) {
            T tmp = list.get(0);
            list.set(0, list.get(end));
            list.set(end, tmp);
            Heap.siftDown(list, 0, end);
        }
    }

    public static <T extends Comparable<T>> void heapSort(T[] arr) {
        heapSort(Arrays.asList(arr));
    }

    // Вспомогательные функции для вывода и проверки

    // Значения дерева по уровням
    public static <T extends Comparable<T>> List<T> levelOrder(TreeNode<T> root) {
        List<T> result = new ArrayList<>();
        if (root == null) {
            return result;
        }
        Deque<TreeNode<T>> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            TreeNode<T> node = queue.poll();
            result.add(node.val);
            if (node.left != null) {
                queue.add(node.left);
            }
            if (node.right != null) {
                queue.add(node.right);
            }
        }
        return result;
    }

    // Проверка: список является убывающей кучей
    public static <T extends Comparable<T>> boolean isMaxHeap(List<T> list) {
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).compareTo(list.get((i - 1) / 2)) > 0) {
                return false;
            }
        }
        return true;
    }

    // Проверка: дерево из узлов является убывающей кучей
    public static <T extends Comparable<T>> boolean isMaxHeapTree(TreeNode<T> root) {
        if (root == null) {
            return true;
        }
        Deque<TreeNode<T>> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            TreeNode<T> node = stack.pop();
            for (TreeNode<T> child : Arrays.asList(node.left, node.right)) {
                if (child != null) {
                    if (child.val.compareTo(node.val) > 0) {
                        return false;
                    }
                    stack.push(child);
                }
            }
        }
        return true;
    }
}
