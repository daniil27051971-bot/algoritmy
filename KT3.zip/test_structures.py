import unittest

from structures import Deque, LinkedList, Queue, Stack


class TestStack(unittest.TestCase):
    def test_lifo_order(self):
        stack = Stack()
        stack.push(1)
        stack.push(2)

        self.assertEqual(stack.peek(), 2)
        self.assertEqual(stack.pop(), 2)
        self.assertEqual(stack.pop(), 1)
        self.assertTrue(stack.is_empty())

    def test_empty_stack_raises_error(self):
        with self.assertRaises(IndexError):
            Stack().pop()


class TestQueue(unittest.TestCase):
    def test_fifo_order(self):
        queue = Queue()
        queue.enqueue("a")
        queue.enqueue("b")

        self.assertEqual(queue.peek(), "a")
        self.assertEqual(queue.dequeue(), "a")
        self.assertEqual(queue.dequeue(), "b")
        self.assertTrue(queue.is_empty())

    def test_empty_queue_raises_error(self):
        with self.assertRaises(IndexError):
            Queue().dequeue()


class TestDeque(unittest.TestCase):
    def test_operations_at_both_ends(self):
        deque = Deque()
        deque.add_front(2)
        deque.add_front(1)
        deque.add_rear(3)

        self.assertEqual(deque.peek_front(), 1)
        self.assertEqual(deque.peek_rear(), 3)
        self.assertEqual(deque.remove_front(), 1)
        self.assertEqual(deque.remove_rear(), 3)
        self.assertEqual(deque.remove_front(), 2)

    def test_empty_deque_raises_error(self):
        with self.assertRaises(IndexError):
            Deque().remove_rear()


class TestLinkedList(unittest.TestCase):
    def test_add_find_and_remove(self):
        linked_list = LinkedList()
        linked_list.append(2)
        linked_list.prepend(1)
        linked_list.append(3)

        self.assertEqual(linked_list.to_list(), [1, 2, 3])
        self.assertEqual(linked_list.find(2), 1)
        self.assertTrue(linked_list.remove(2))
        self.assertEqual(linked_list.to_list(), [1, 3])
        self.assertFalse(linked_list.remove(10))
        self.assertEqual(linked_list.size(), 2)


if __name__ == "__main__":
    unittest.main()
