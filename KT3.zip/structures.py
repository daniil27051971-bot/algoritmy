class Stack:

    def __init__(self):
        self._items = []

    def push(self, value):
        self._items.append(value)

    def pop(self):
        if self.is_empty():
            raise IndexError("стек пуст")
        return self._items.pop()

    def peek(self):
        if self.is_empty():
            raise IndexError("стек пуст")
        return self._items[-1]

    def is_empty(self):
        return len(self._items) == 0

    def size(self):
        return len(self._items)


class Queue:

    def __init__(self):
        self._items = []
        self._head = 0

    def enqueue(self, value):
        self._items.append(value)

    def dequeue(self):
        if self.is_empty():
            raise IndexError("очередь пуста")

        value = self._items[self._head]
        self._head += 1

        if self._head > 50 and self._head * 2 > len(self._items):
            self._items = self._items[self._head:]
            self._head = 0

        return value

    def peek(self):
        if self.is_empty():
            raise IndexError("очередь пуста")
        return self._items[self._head]

    def is_empty(self):
        return self._head == len(self._items)

    def size(self):
        return len(self._items) - self._head


class Deque: 

    def __init__(self):
        self._items = []

    def add_front(self, value):
        self._items.insert(0, value)

    def add_rear(self, value):
        self._items.append(value)

    def remove_front(self):
        if self.is_empty():
            raise IndexError("дек пуст")
        return self._items.pop(0)

    def remove_rear(self):
        if self.is_empty():
            raise IndexError("дек пуст")
        return self._items.pop()

    def peek_front(self):
        if self.is_empty():
            raise IndexError("дек пуст")
        return self._items[0]

    def peek_rear(self):
        if self.is_empty():
            raise IndexError("дек пуст")
        return self._items[-1]

    def is_empty(self):
        return len(self._items) == 0

    def size(self):
        return len(self._items)


class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:

    def __init__(self):
        self.head = None
        self._size = 0

    def append(self, value):
        new_node = Node(value)

        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next is not None:
                current = current.next
            current.next = new_node

        self._size += 1

    def prepend(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node
        self._size += 1

    def remove(self, value):
        previous = None
        current = self.head

        while current is not None:
            if current.value == value:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                self._size -= 1
                return True

            previous = current
            current = current.next

        return False

    def find(self, value):
        current = self.head
        position = 0

        while current is not None:
            if current.value == value:
                return position
            current = current.next
            position += 1

        return -1

    def is_empty(self):
        return self.head is None

    def size(self):
        return self._size

    def to_list(self):
        values = []
        current = self.head

        while current is not None:
            values.append(current.value)
            current = current.next

        return values


if __name__ == "__main__":
    stack = Stack()
    stack.push(10)
    stack.push(20)
    print("Стек:", stack.pop())

    queue = Queue()
    queue.enqueue("первый")
    queue.enqueue("второй")
    print("Очередь:", queue.dequeue())

    linked_list = LinkedList()
    linked_list.append(1)
    linked_list.append(2)
    linked_list.prepend(0)
    print("Связный список:", linked_list.to_list())
